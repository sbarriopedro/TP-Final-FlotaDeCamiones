interface IChofer{
    perfil:string,
}

export {IChofer}