interface IService {

    nombre:string,
    KMSERVICEACEITE:10000
    KMSERVICEFILTRO:20000
    KMSERVICENEUMATICO:70000
}

export{IService}