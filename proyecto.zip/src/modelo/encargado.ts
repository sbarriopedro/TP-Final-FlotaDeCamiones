interface IEncargado{
    perfil:string,
}

export{IEncargado}