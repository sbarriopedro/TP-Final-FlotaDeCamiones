interface IUbicacion {

    latitud:number,
    longitud:number,

}

export {IUbicacion}