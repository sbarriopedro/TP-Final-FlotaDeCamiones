interface IUsuario {

    dni:number,
    nombre:string,
    apellido:string,
    userID:string,
    password:string,
}

export {IUsuario}
