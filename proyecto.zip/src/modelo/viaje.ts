interface IViaje{

    id:string,
}

export {IViaje}