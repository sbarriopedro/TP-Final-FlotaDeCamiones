interface ICamion {

    patente: string,
    kilometraje: number,
    ultimoServiceAceite: number,
    ultimoServiceNeumatico: number,
    ulitmoServiceFiltro: number,
    enServicio: boolean,   

}

export {ICamion}